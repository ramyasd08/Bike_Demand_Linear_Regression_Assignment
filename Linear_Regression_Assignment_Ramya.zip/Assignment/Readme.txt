The dataset contains information about the bike rental company boombikes which is computer controlled and wants to know how different variables help in predicting the demand of the bike.

The prediction of the count of the bikes is based on linear regression model as there is a linear relationhip between the target and the predictor variables. 

We have used RFE method to elimate the not significant features first and then used manual elimiation techinques to determine the final model. 